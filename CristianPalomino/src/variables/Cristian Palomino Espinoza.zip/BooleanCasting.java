package variables;

public class BooleanCasting {
	public static void main(String[] args) {
		boolean flag1 = true;
		
		//CASTING EXPLÍCITO: INT => BYTE
		byte numByte = flag1;
		
		//CASTING EXPLÍCITO: INT => BYTE
		short numShort = flag1
		
		//CASTING EXPLÍCITO: INT => SHORT
		int numInt = flag1;
		
		//CASTING IMPLÍCITO: INT => LONG
		long numLong = flag1;
		
		//CASTING IMPLÍCITO: INT => FLOAT
		float numFloat = flag1;
		
		//CASTING IMPLÍCITO: INT => DOUBLE
		double numDouble = flag1;
		
		
		//CASTING EXPLÍCITO: INT => CHAR 
		char caracter = flag1;
		
		
		System.out.println("CASTING EXPLÍCITO: BOOLEAN => BYTE no se puede hacer casting");
		System.out.println("CASTING EXPLÍCITO: BOOLEAN => SHORT no se puede hacer casting");
		System.out.println("CASTING EXPLÍCITO: BOOLEAN => INT no se puede hacer casting");
		System.out.println("CASTING IMPLÍCITO: BOOLEAN => LONG no se puede hacer casting");
		System.out.println("CASTING IMPLÍCITO: BOOLEAN => FLOAT no se puede hacer casting");
		System.out.println("CASTING IMPLÍCITO: BOOLEAN => DOUBLE no se puede hacer casting");
		System.out.println("CASTING EXPLÍCITO: BOOLEAN => CHAR no se puede hacer casting");
		
		
		
		
		
		
		
		
		
	}
}
